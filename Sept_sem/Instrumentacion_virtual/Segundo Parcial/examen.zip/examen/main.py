from gc import enable
from numpy import NAN
import paho.mqtt.client as mqtt 
import random 
import time 
from datetime import datetime 
import json
import gui as qt5
import BDgenerator as dbgen
from pushbullet import PushBullet
import threading  # Para usar hilos

# Configuración del broker MQTT y la base de datos MySQL 
broker = '69793896c6e246f3be6e92cda7404456.s1.eu.hivemq.cloud' 
port = 8883 
topic = "sensor/data"  

# Definir las 5 ubicaciones y sus sensores 
locations = [ 
    {"name": "LibreCultivo", "lat": 21.1526, "lon": -101.7116}, 
    {"name": "Canton", "lat": 22.1565, "lon": -100.9855}, 
    {"name": "UDLSB", "lat": 23.6345, "lon": -102.5528}, 
    {"name": "Jocotepec", "lat": 24.1421, "lon": -110.3107}, 
    {"name": "Cerro", "lat": 19.4326, "lon": -99.1332} 
]

token = "o.fVjHTnBVHuAIpzFUxHQ2HBBvhCHJb1Uh"
cel = "Motorola Moto g(60)"

pb = PushBullet(token)  # Conectar con PushBullet
dev1 = pb.new_device(cel)  # Añadir el dispositivo móvil

def on_connect(client, userdata, flags, rc): 
    if rc == 0: 
        print("Conexión exitosa a MQTT Broker") 
    else: 
        print(f"Fallo de conexión, código: {rc}") 

loc = 0
def valores_sensor():
    global loc

    cliente = mqtt.Client() 
    usuario = "CultivoHidroponico0" 
    contraseña = "CultivoHidroponico0" 
    cliente.username_pw_set(usuario, contraseña) 
    cliente.tls_set() 
    cliente.on_connect = on_connect 
    cliente.connect(broker, port, keepalive=60) 
    cliente.loop_start() 

    while True: 
        for location in locations: 
            # Simulación de datos de sensores 
            if loc <= 4:
                if qt5.enablebandera[loc] == 1:
                    temperatura = round(random.uniform(20.0, 40.0), 2) 
                    humedad = round(random.uniform(30.0, 90.0), 2)
                    luminosidad = random.randint(100, 500)
                else: 
                    temperatura = 0 
                    humedad = 0
                    luminosidad = 0
            else:
                loc = 0

            # Alertas
            if luminosidad < 300: 
                pb.push_note("ALERTA", f"Se bajó la intensidad de luz en {location['name']}")
            if humedad < 50: 
                pb.push_note("ALERTA", f"Se bajó la humedad en {location['name']}")

            # Otros sensores si es necesario 
            datos_sensor = { 
                "nombre_sensor": location["name"], 
                "latitud": location["lat"], 
                "longitud": location["lon"], 
                "temperatura": temperatura, 
                "humedad": humedad,
                "luminosidad": luminosidad  
            } 

            # Publicar en MQTT 
            cliente.publish(topic, json.dumps(datos_sensor)) 
            print(f"Datos enviados: {datos_sensor}") 

            # Insertar en MySQL 
            dbgen.insert_new_data(location["name"], temperatura, humedad, luminosidad)

        time.sleep(15)  # Enviar datos cada 15 segundos 

if __name__ == "__main__": 
    # Crear un hilo solo para la simulación de los sensores
    hilo_sensores = threading.Thread(target=valores_sensor) 
    hilo_sensores.daemon = True  # Esto hace que el hilo termine cuando el programa principal termine
    hilo_sensores.start()  # Iniciar el hilo de sensores

    # Configuración de la GUI
    qt5.GUI.btnShow1.clicked.connect(lambda: qt5.visualizartabla(qt5.BDsens.tableSensores[0]))    # Al ser oprimido este botón se mostrará la tabla. 
    qt5.GUI.btnShow2.clicked.connect(lambda: qt5.visualizartabla(qt5.BDsens.tableSensores[1]))    
    qt5.GUI.btnShow3.clicked.connect(lambda: qt5.visualizartabla(qt5.BDsens.tableSensores[2]))    
    qt5.GUI.btnShow4.clicked.connect(lambda: qt5.visualizartabla(qt5.BDsens.tableSensores[3]))    
    qt5.GUI.btnShow5.clicked.connect(lambda: qt5.visualizartabla(qt5.BDsens.tableSensores[4]))
    qt5.GUI.btnDesac1.clicked.connect(lambda: qt5.eneable(0,0))    # Desactivar envío de datos. 
    qt5.GUI.btnDesac2.clicked.connect(lambda: qt5.eneable(1,0))     
    qt5.GUI.btnDesac3.clicked.connect(lambda: qt5.eneable(2,0))     
    qt5.GUI.btnDesac4.clicked.connect(lambda: qt5.eneable(3,0))     
    qt5.GUI.btnDesac5.clicked.connect(lambda: qt5.eneable(4,0))     
    qt5.GUI.btnAct1.clicked.connect(lambda: qt5.eneable(0,1))      # Activar envío de datos. 
    qt5.GUI.btnAct2.clicked.connect(lambda: qt5.eneable(1,1))      
    qt5.GUI.btnAct3.clicked.connect(lambda: qt5.eneable(2,1))      
    qt5.GUI.btnAct4.clicked.connect(lambda: qt5.eneable(3,1))      
    qt5.GUI.btnAct5.clicked.connect(lambda: qt5.eneable(4,1))         

    # Mostrar la GUI y ejecutar la aplicación
    qt5.GUI.show()
    qt5.app.exec()
