from PyQt5 import QtWidgets, uic, QtCore
import BDgenerator as BDsens

#Config de los gui
app = QtWidgets.QApplication([])
GUI = uic.loadUi("E:\Referencias a la universidad\Sept_sem\Instrumentacion_virtual\Segundo Parcial\examen\P2_ProyectoParcial.ui")

#Funciones
dic = {
    BDsens.tableSensores[0] : GUI.tabla1,
    BDsens.tableSensores[1] : GUI.tabla2,
    BDsens.tableSensores[2] : GUI.tabla3,
    BDsens.tableSensores[3] : GUI.tabla4,
    BDsens.tableSensores[4] : GUI.tabla5,
}

def visualizartabla(tb):
    try:
        #Checamos datos
        tabla = BDsens.fetch_data(tb)
        for fila in tabla:
            print(f"ID: {fila[0]}, Humedad: {fila[1]}, Temperatura: {fila[2]}, Luminisidad: {fila[3]}")
        
        #Llenamos tabla
        tablaOBJ = dic.get(tb)
        tablaOBJ.setRowCount(0)

        for no_fila, dato_fila in enumerate(tabla):
            tablaOBJ.insertRow(no_fila)  # Inserta una nueva fila
            print("Fila insertada numero:", no_fila)
            for no_columna, dato in enumerate(dato_fila):
                item =  QtWidgets.QTableWidgetItem(str(dato))  # Crea un item para la celda
                tablaOBJ.setItem(no_fila, no_columna, item)  # Establece el item en la celda
                print(f"Columnas {no_columna}: {dato}")

    except Exception as e:
        msj = QtWidgets.QMessageBox()
        msj.setWindowTitle('Error')
        msj.setText("Hubo un error al conseguir los datos")
        msj.setStandardButtons(QtWidgets.QMessageBox.Ok)
        msj.exec_()

enablebandera = [1,1,1,1,1] #Inician todos habilitados
def eneable(localizacion,stado):
    enablebandera[localizacion] = stado        