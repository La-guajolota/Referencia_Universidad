import pymysql
import random

passWord = '5829100sqlXD'
dbName = 'invernaderos'
tableSensores = ['LibreCultivo','Canton','UDLSB','Jocotepec','Cerro']

def connect_db():
    return pymysql.connect(
        host='localhost',
        user='root',
        password=passWord
    )

def setup_database(table):
    db = connect_db()
    cursor = db.cursor()
    
    queries = {
        "newDB": f"CREATE DATABASE IF NOT EXISTS {dbName}",  
        "use_": f"USE {dbName}",
        "createTable": f"""
            CREATE TABLE IF NOT EXISTS {table} (
                id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
                Humedad FLOAT NOT NULL,
                Temperatura FLOAT NOT NULL,
                Luminisidad FLOAT NOT NULL,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """,
    }

    try:
        cursor.execute(queries["newDB"])  
        cursor.execute(queries["use_"])    
        cursor.execute(queries["createTable"])  
        print("Base de datos y/o tabla creadas exitosamente.")
    except Exception as e:
        print(f"Ocurrió un error: {e}")
    finally:
        cursor.close()
        db.close()

def insert_new_data(tabla,humedad, temperatura, luminisidad):
    db = connect_db()
    cursor = db.cursor()
    cursor.execute(f"USE {dbName}")    
    cursor.execute(f"INSERT INTO {tabla} (Humedad, Temperatura, Luminisidad) VALUES (%s, %s, %s)", (humedad, temperatura, luminisidad))
    db.commit()
    cursor.close()
    db.close()

def fetch_data(tabla):
    db = connect_db()
    cursor = db.cursor()
    cursor.execute(f"USE {dbName}")    
    cursor.execute(f"SELECT * FROM {tabla}")
    data = cursor.fetchall()
    cursor.close()
    db.close()
    return data

#Corremos
for table in tableSensores:
    setup_database(table)